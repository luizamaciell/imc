package com.example.appimc_inf3am;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etWeight;
    EditText etHeight;
    TextView txtResult;

    TextView txtResult2;

    ImageView imgView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        txtResult = findViewById(R.id.txtResult);
        txtResult2 = findViewById(R.id.txtResult2);
        imgView = findViewById(R.id.imageView3);

        Button btnResult = findViewById(R.id.btnResult);
        btnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float weight = Float.parseFloat(etWeight.getText().toString());
                float height = Float.parseFloat((etHeight.getText().toString()));
                float result = weight / (height * height);
                txtResult.setText("IMC = " + String.format("%.2f", result));

                if (result < 18.5) {
                    txtResult2.setText("Abaixo");
                    imgView.setImageResource(R.drawable.baixo);
                } else if (result > 18.5 && result < 24.9) {
                    txtResult2.setText("Normal");
                    imgView.setImageResource(R.drawable.normal);
                } else if (result > 25 && result < 29.9) {
                    txtResult2.setText("Acima");
                    imgView.setImageResource(R.drawable.acima);
                } else if (result > 30 && result < 34.9) {
                    txtResult2.setText("Obesidade I");
                    imgView.setImageResource(R.drawable.obesidadei);
                } else if (result > 35 && result < 39.9) {
                    txtResult2.setText("Obesidade II");
                    imgView.setImageResource(R.drawable.obesidadeii);
                } else if (result > 40) {
                    txtResult2.setText("Obesidade III");
                    imgView.setImageResource(R.drawable.obesidadeiii);
                }
            }
        });
       }
    }